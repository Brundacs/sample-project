if (password !== '12345') {
    alert('Incorrect password! Please try again.');
    form.reset();
    } else {
    window.location.href = 'password.html';
    }
    
